#include "Colourizer.h"

Colourizer::Colourizer() {

}

std::string Colourizer::colourize(Colour colour, Shape shape) {
    std::stringstream ss;
    std::string colouredString;
    if(colour == RED) {
        ss << "\u001b[38;5;1m" << colour << shape << "\u001b[0m";
        ss >> colouredString;

    } else if(colour == ORANGE ){
        ss << "\u001b[38;5;166m" << colour << shape << "\u001b[0m";
        ss >> colouredString;

    } else if(colour == YELLOW ){
        ss << "\u001b[38;5;3m" << colour << shape << "\u001b[0m";
        ss >> colouredString;

    } else if(colour == GREEN ){
       ss << "\u001b[38;5;2m" << colour << shape << "\u001b[0m";
       ss >> colouredString;

    } else if(colour == BLUE ){
        ss << "\u001b[38;5;4m" << colour << shape << "\u001b[0m";
        ss >> colouredString;

    } else {
        ss << "\u001b[38;5;54m" << colour << shape << "\u001b[0m";
        ss >> colouredString;
    }

    return colouredString;
}
