#ifndef ASSIGN2_REPLAY_H
#define ASSIGN2_REPLAY_H
#include <iostream>
#include <math.h>
#include "LinkedList.h"
#include <string>
#include "Tile.h"

class Replay {
public:
    //Xuan Ye - s3586968  
    Replay();
    void addToReplay(Tile* coor, Tile* tile);
    std::string showReplay(std::string player1,std::string player2 );
private:
    LinkedList* listOfCoordinates;
    LinkedList* listOfTiles;
};

#endif //ASSIGN2_REPLAY_H
