#include "Replay.h"


Replay::Replay(){
   listOfCoordinates = new LinkedList();
   listOfTiles = new LinkedList();
}

void Replay::addToReplay(Tile* coor, Tile* tile){

  listOfCoordinates->addBack(coor);
  listOfTiles->addBack(tile);

}
std::string Replay::showReplay(std::string player1,std::string player2 ){
std::string result = "";
  for (int i = 0; i <  listOfCoordinates->getSize(); ++i) {
    if (remainder(i, 2) == 0) {
      result += player1;
      result += " placed ";
      result += listOfTiles->get(i)->toString();
      result += " at ";
      result += listOfCoordinates->get(i)->toString();
      result += "\n";
    }
    else {
      result += player2 ;
      result += " placed ";
      result += listOfTiles->get(i)->toString() ;
      result += " at ";
      result += listOfCoordinates->get(i)->toString();
      result += "\n";
    }
  }
  return result;
}
