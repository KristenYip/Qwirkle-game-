#ifndef ASSIGN2_STUDENT_H
#define ASSIGN2_STUDENT_H

#define ASCII_NUM 48
#define ASCII_LETTER 65
#define NUM_PLAYERS 2


#include <iostream>
#include <string>
#include <vector>
#include <math.h>

#include "TileCodes.h"
#include "Replay.h"

class Player;
class Tile;
class TileBag;
class LinkedList;
class Validator;
//#typedef std::vector<std::vector<Tile> > Board;

class GameBoard {
public:
  //Tristan - S3784828
  GameBoard(int rows, int cols, TileBag* tileBag);
  ~GameBoard();
  std::string displayGameBoard(bool save);
  bool inBounds(int row, int col);
  bool addPosition(std::string input, Player* player, Replay* r);

  //Evan - s3688949
  bool proposeTile(Tile* proposedTile, int row, int col, Player* player);
  bool directionCheckandScoreShape(Tile* proposedTile, int locRow, int locCol, int dirRow, int dirCol, int* tileScore);
  bool directionCheckandScoreColour(Tile* proposedTile, int locRow, int locCol, int dirRow, int dirCol, int* tileScore);

  //Tristan - S3784828
  void addPlayer(std::string name, int score);
  Player* getPlayer(int i);
  std::string displayInfo(int playersTurn);
  bool checkPlayerHands();
  std::string getFinalResults();
  int convertRow(std::string row);
  int convertCol(std::string col);
  int divideCol(int col);
  int numPossibleChars(int cols);

  bool emptyBoard;
  int rows;
  int cols;
  std::vector<std::vector<Tile>> tileBoard;
  Player* players[NUM_PLAYERS];
  int playerCount;
  TileBag* tileBag;
};

#endif // ASSIGN2_GAMEBOARD_H
