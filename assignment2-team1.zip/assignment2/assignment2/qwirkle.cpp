#include <iostream>

#include "System.h"

#define EXIT 0

int main(void) {
  System* system = new System();
  system->runQwirkle();
  return EXIT;
}
