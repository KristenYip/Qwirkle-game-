
#ifndef ASSIGN2_NODE_H
#define ASSIGN2_NODE_H

class Tile;

class Node {
public:
    //Tristan - S3784828
   Node(Tile* tile, Node* next);
   Node(Tile* tile, Node* next, Node* prev);
   Node(Node& other);
   Tile* getTile();

   Tile*    tile;
   Node*    next;
   Node*    prev;
};

#endif // ASSIGN2_NODE_H
