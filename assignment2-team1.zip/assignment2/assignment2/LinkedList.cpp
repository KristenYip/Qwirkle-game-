#include "LinkedList.h"
#include "Node.h"
#include "Tile.h"
#include "Colourizer.h"

LinkedList::LinkedList() {
   head = nullptr;
   tail = nullptr;
   size = 0;
}

LinkedList::~LinkedList() {
  clear();
}

void LinkedList::clear() {
  while (size != 0) {
    deleteFront();
  }
}

void LinkedList::addBack(Tile* tile) {
  Node* newNode;
  if (head == nullptr) {
    addWhenEmpty(tile);
  }
  else {
    Node* curr = head;
    while (curr != tail) {
      curr = curr->next;
    }
    newNode = new Node(tile, nullptr, curr);
    curr->next = newNode;
    tail = newNode;
  }
  size++;
}

void LinkedList::addFront(Tile* tile) {
  if (head == nullptr) {
    addWhenEmpty(tile);
  }
  else {
    Node* newNode = new Node(tile, head, nullptr);
    head->prev = newNode;
    head = newNode;
  }
  size++;
}

void LinkedList::removeTile(Tile* tile) {

  if (head->getTile()->equals(tile)) {
    head = head->next;
  }
  else {
    Node* curr = head;
    Node* toDelete;
    while (!curr->getTile()->equals(tile)) {
      curr = curr->next;
    }
    Node* prev = curr->prev;
    Node* next = curr->next;
    prev->next = next;
    next->prev = prev;
    toDelete = curr;
    delete toDelete;
  }
  size--;
}

bool LinkedList::contains(Tile* tile) {
  bool contains = false;
  Node* curr = head;
  while (contains == false && curr->next != nullptr) {
    if (curr->getTile()->equals(tile)) {
      contains = true;
    }
    curr = curr->next;
  }
  return contains;
}

Tile* LinkedList::getBack() {
  return tail->getTile();
}

Tile* LinkedList::getFront() {
  return head->getTile();
}

void LinkedList::deleteFront() {
  if (head != nullptr) {
    Node* toDelete = head;
    head = head->next;
    head->prev = nullptr;
    delete toDelete;
  }
  if (head == nullptr) {
    tail = nullptr;
  }
  size--;
}

void LinkedList::deleteBack() {
  Node* curr = head;
  Node* toDelete = tail;
  while (curr->next != tail) {
    curr = curr->next;
  }
  tail = curr;
  delete toDelete;
  size--;
}

int LinkedList::getSize() {
  return size;
}

std::string LinkedList::toString() {
  Node* curr = head;
  std::string tileString = "";
  if (head != nullptr) {
    while (curr->next != nullptr) {
      tileString += curr->getTile()->toString();
      tileString += ",";
      curr = curr->next;
    }
  }
  return tileString.substr(0, tileString.size() - 1);
}

std::string LinkedList::colourToString() {
  Node* curr = head;
  std::string tileString = "";
  if (head != nullptr) {
    while (curr->next != nullptr) {
      tileString += curr->getTile()->colourToString();
      tileString += ",";
      curr = curr->next;
    }
  }
  return tileString.substr(0, tileString.size() - 1);
}

Tile* LinkedList::get(int i) {
  Node* curr = head;
  bool found = false;
  int count = 0;
  while (!found && curr->next != nullptr) {
    if (count == i) {
      found = true;
    }
    curr = curr->next;
    count++;
  }
  return curr->getTile();
}

void LinkedList::addWhenEmpty(Tile* tile) {
  Node* newNode = new Node(tile, nullptr, nullptr);
  head = newNode;
  tail = newNode;
}
