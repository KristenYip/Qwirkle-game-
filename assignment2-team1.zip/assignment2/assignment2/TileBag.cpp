#include "TileBag.h"
#include "LinkedList.h"
#include "TileCodes.h"

TileBag::TileBag() {
  list = new LinkedList();
  tileCount = 0;
  TileBag::generateTiles();
  TileBag::createRandomList();
}

void TileBag::generateTiles() {
  Colour colours[ARRAY_SIZE] = {'R', 'O', 'Y', 'G', 'B', 'P'};
  Shape shapes[ARRAY_SIZE] = {1, 2, 3, 4, 5, 6};

  for (int i = 0; i < NUM_TYPES; ++i) {
    for (int colour = 0; colour < ARRAY_SIZE; ++colour) {
      for (int shape = 0; shape < ARRAY_SIZE; ++shape) {
        tiles[tileCount] = new Tile(colours[colour], shapes[shape]);
        tileCount++;
      }
    }
  }
}

 void TileBag::createRandomList() {
  int min = 0;
  int max = tileCount - 1;
  std::time_t t = std::time(0);
  int seed = (int) t;

  std::default_random_engine engine(seed);
  std::uniform_int_distribution<int> uniform_dist(min, max);
  int value = -1;
  while (tileCount != 0) {
    value = uniform_dist(engine);
    if (tiles[value] != nullptr) {
      list->addBack(tiles[value]);
      tiles[value] = nullptr;
      tileCount--;
    }
  }
}

LinkedList* TileBag::getList() {
  return list;
}
