#include "System.h"
#include "Tile.h"
#include "GameBoard.h"
#include "TileBag.h"
#include "Validator.h"
#include "LinkedList.h"
#include "Player.h"
#include "Menu.h"
#include "Replay.h"
#include <fstream>

System::System() {

}

void System::runQwirkle() {
  Menu* mainMenu = new Menu();
  std::cout << mainMenu->displayWelcomeMessage() << std::endl;
  bool end = false;
  while (!end) {
    char userSelection;
    std::cout << mainMenu->displayMainMenu() << std::endl;
    std::cout << ">";
    std::cin >> userSelection;
    if (userSelection == '1') {
      std::string player1 = "";
      while (player1.length() == 0) {
        player1 = System::getPlayerName(1);
      }
      std::string player2 = "";
      while (player2.length() == 0) {
        player2 = System::getPlayerName(2);
      }
      runNewGame(player1, player2);
    }
    if (userSelection == '2') {

    }

    if (userSelection == '3') {
      std::cout << mainMenu->displayStudentInformation() << std::endl;
    }

    if (userSelection == '4') {
      end = true;
    }
  }
}

std::string System::getPlayerName(int playerNumber) {
  Validator* v = new Validator();
  bool validString = false;
  std::string userInput;
  while (!validString) {
    std::cout << "Please enter a name for player " << std::to_string(playerNumber) << " (upper case only)" << std::endl;
    std::cout << ">";
    if (std::cin.eof()) {
      exit(0);
    }
    std::getline(std::cin, userInput);

    if (v->isUpper(userInput)) {
      validString = true;
    }
  }
  return userInput;
}

void System::runNewGame(std::string player1, std::string player2) {
  Replay* replay = new Replay();
  int playersTurn = 0;
  TileBag* tileBag = new TileBag();
  GameBoard* board = new GameBoard(GAMEBOARD_SIZE_ROW,GAMEBOARD_SIZE_COL, tileBag);
  board->addPlayer(player1, 0);
  board->addPlayer(player2, 0);
  playGame(board, tileBag, playersTurn, replay);
  std::cout << board->getFinalResults() << std::endl;
  std::cout << replay->showReplay(board->getPlayer(0)->getName(), board->getPlayer(1)->getName()) << std::endl;
}

void System::playGame(GameBoard* board, TileBag* tileBag, int playersTurn, Replay* replay) {
  bool end = false;
  std::string userInput;
  Validator* v = new Validator();
  while(!end) {
    userDisplay(board, playersTurn);

    if (std::cin.eof()) {
      exit(0);
    }

    std::getline(std::cin, userInput);

    if (tileBag->getList()->getSize() == 0 || board->checkPlayerHands()) {
      end = true;
    }
    if (userInput.substr(0, 1).compare("p") == 0 && v->validInput(userInput, board->getPlayer(playersTurn), true)) {
      if (board->addPosition(userInput, board->getPlayer(playersTurn), replay)) {
        board->getPlayer(playersTurn)->getHand()->removeTile(v->getTileFromInput(userInput, true));
        System::endTurn(board, tileBag, playersTurn);
      }
      else {
        std::cout << "\nError - invalid position\n" << std::endl;
      }
    }
    else if (userInput.substr(0,1).compare("r") == 0 && v->validInput(userInput, board->getPlayer(playersTurn), false)) {
      board->getPlayer(playersTurn)->getHand()->removeTile(v->getTileFromInput(userInput, false));
      tileBag->getList()->addBack(v->getTileFromInput(userInput, false));
      System::endTurn(board, tileBag, playersTurn);
    }
    else if (userInput.substr(0,5).compare("save ") == 0) {
      System::saveGame(userInput, board, tileBag, playersTurn);
    }
    else if (userInput.compare("help") == 0) {
      Menu* menu = new Menu();
      std::cout << menu->displayHelp() << std::endl;
    }
    else if (userInput.compare("forfeit") == 0) {
      end = true;
    }
    else {
      std::cout << "\nError - invalid input\n" << std::endl;
    }
    }
}

void System::endTurn(GameBoard* board, TileBag* tileBag, int& playersTurn) {
  board->getPlayer(playersTurn)->getHand()->addBack(tileBag->getList()->getFront());
  tileBag->getList()->deleteFront();
  if (playersTurn == 0) {
    playersTurn = 1;
  }
  else {
    playersTurn = 0;
  }
}

void System::userDisplay(GameBoard* board, int playersTurn) {
  std::cout << board->displayInfo(playersTurn) << std::endl;
  std::cout << board->displayGameBoard(false) << std::endl;
  std::cout << board->getPlayer(playersTurn)->getHandInfo() << std::endl;
  std::cout << ">";
}

void System::saveGame(std::string userInput, GameBoard* board, TileBag* tileBag, int& playersTurn){
  // Remainder of string after the first whitespace is set as the file name
  std::size_t pos = userInput.find(' ');
  std::string saveName = userInput.substr(++pos);
  std::ofstream outFile;

  // Open a new file with extension ".save"
  // e.g. saveFile.save
  outFile.open(saveName + ".save");
  if (outFile.good()) {
    // Save Player Details
    for (int playerCount = 0; playerCount < NUM_PLAYERS; ++playerCount) {
      outFile << board->getPlayer(playerCount)->getName() << std::endl;
      outFile << board->getPlayer(playerCount)->getScore() << std::endl;
      outFile << board->getPlayer(playerCount)->getHand()->toString() << std::endl;
    }
    // Save current game board without colours
    outFile << board->displayGameBoard(true) << std::endl;
    // Save remaining tiles in tile bag
    outFile << tileBag->getList()->toString() << std::endl;
    // Save the name of the current player's turn
    outFile << board->getPlayer(playersTurn)->getName() << std::endl;
    outFile.flush();

    std::cout << "Successfully saved!" << std::endl;
  }
  else {
    std::cerr << "Save failed." << std::endl;
  }
  outFile.close();
}


void System::loadGame() {
    std::string saveName;
    std::cout << "Enter the filename from which to load a game(do not include the file type '.save')" << std::endl;
    std::cout << ">";
    std::cin >> saveName;

    std::string playerNames[NUM_PLAYERS];
    int playersTurn = 0;

    // Attempt to open the user's input save file
    // File must have extension ".save"
    std::ifstream in;
    in.open(saveName + ".save");
    if (in.fail()) {
        std::cerr << "Failed to open game save." << std::endl;
    }
    else {
        Replay* replay = new Replay();
        TileBag* tileBag = new TileBag();
        GameBoard* board = new GameBoard(26, 26, tileBag);
        while (!in.eof()) {
            // For loop loads player details
            for (int playerCount = 0; playerCount < NUM_PLAYERS; ++playerCount) {
                std::string playerName;
                int playerScore;

                // Set current player's name and score
                in >> playerName;
                playerNames[playerCount] = playerName;
                in >> playerScore;
                board->addPlayer(playerNames[playerCount], playerScore);

                //hand
            }

            /*
             * Loop to check if loop for player details is setting inputs correctly
            for (int i = 0; i < NUM_PLAYERS; ++i) {
                std::cout << board->getPlayer(i)->getName() << std::endl;
                std::cout << board->getPlayer(i)->getScore() << std::endl;
            }
            */

            //board

            //tilebag

            // If else to see if the name of the current player's turn matches and appropriately matches
            //  which player's turn it is
            std::string playerTurnName;
            in >> playerTurnName;
            if (playerTurnName == playerNames[0]) {
                playersTurn = 0;
            }
            else {
                playersTurn = 1;
            }
        }
        System::playGame(board, tileBag, playersTurn, replay);
    }
    in.close();
}
