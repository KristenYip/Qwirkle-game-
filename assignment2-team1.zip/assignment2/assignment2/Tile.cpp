
#include "Tile.h"
#include "Colourizer.h"

Tile::Tile(Colour colour, Shape shape) :
  colour(colour),
  shape(shape)
  {
  }

Tile::~Tile() {
  colour = '0';
  shape = 0;
}

std::string Tile::toString() {
  std::string tileString = "";
  if (colour == '0') {
    tileString = "  ";
  }
  else {
    tileString += colour;
    tileString += std::to_string(shape);
  }
  return tileString;
}

bool Tile::equals(Tile* tile) {
  bool equals = false;
  if (colour == tile->getColour() && shape == tile->getShape()) {
    equals = true;
  }
  return equals;
}

Colour Tile::getColour() {
  return colour;
}

Shape Tile::getShape() {
  return shape;
}


// Empty... for now?

//Adding one method
std::string Tile::colourToString() {
  Colourizer* colourizer = new Colourizer();
  std::string colouredString = "  ";
  if (colour != '0') {
    colouredString = colourizer->colourize(colour, shape);
  }
  return colouredString;
}
