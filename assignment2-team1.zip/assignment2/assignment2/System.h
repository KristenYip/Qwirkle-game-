#ifndef ASSIGN2_SYSTEM_H
#define ASSIGN2_SYSTEM_H

#include <iostream>
#include <string>
#include <stdlib.h>
#include <cstdio>
#include <ctype.h>

#define NUM_PLAYERS 2
#define GAMEBOARD_SIZE_ROW 26
#define GAMEBOARD_SIZE_COL 26

class Replay;
class Tile;
class GameBoard;
class TileBag;
class Validator;
class LinkedList;
class Player;
class Menu;

class System {
public:
  //Tristan - S3784828
  System();
  void runQwirkle();
  std::string getPlayerName(int playerNumber);
  void runNewGame(std::string player1, std::string player2);
  void playGame(GameBoard* board, TileBag* tileBag, int playersTurn, Replay* replay);
  void endTurn(GameBoard* board, TileBag* tileBag, int& playersTurn);
  void userDisplay(GameBoard* board, int playersTurn);

  //Johnson - S3586968
  void saveGame(std::string userInput, GameBoard* board, TileBag* tileBag, int& playersTurn);
  void loadGame();
};

#endif // ASSIGN2_SYSTEM_H
