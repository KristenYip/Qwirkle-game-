#ifndef ASSIGN2_VALIDATOR_H
#define ASSIGN2_VALIDATOR_H

#define ASCII_NUM 48
#define ASCII_LETTER 65

#include <string>
#include <stdio.h>
#include <ctype.h>
#include <cstring>
#include <cstdio>

class Player;
class Tile;
class LinkedList;

class Validator {
public:
  //Tristan - S3784828
  Validator();
  bool isUpper(std::string string);
  bool charMatches(char character, std::string string);
  int convertCharToInt(char letter, bool useLetter);
  char convertToChar(std::string convertFrom, bool useLetter);
  bool validInput(std::string input, Player* player, bool place);
  Tile* getTileFromInput(std::string input, bool place);
};

#endif // ASSIGN2_VALIDATOR_H
