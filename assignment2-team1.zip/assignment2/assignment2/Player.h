#ifndef ASSIGN2_PLAYER_H
#define ASSIGN2_PLAYER_H

#define HAND_SIZE 6

#include <string>

class LinkedList;
class TileBag;

class Player {
public:
  //Tristan - S3784828
  Player(std::string name, int score, TileBag* tileBag);
  ~Player();
  void generateHand(LinkedList* list);
  LinkedList* getHand();
  std::string getHandInfo();
  std::string getName();
  int getScore();

  //Evan -s3688949
  void addScore(int scored);

  //Tristan - S3784828
  std::string playerInfo();
  std::string toString();

  std::string name;
  int score;
  LinkedList* hand;
  TileBag* tileBag;
};

#endif // ASSIGN2_PLAYER_H
