
#ifndef ASSIGN2_LINKEDLIST_H
#define ASSIGN2_LINKEDLIST_H

#include <string>
#include <iostream>

class Node;
class Tile;
class Colourizer;

class LinkedList {
public:
  //Tristan - S3784828
   LinkedList();
   ~LinkedList();
   void clear();
   void addBack(Tile* tile);
   void addFront(Tile* tile);
   void removeTile(Tile* tile);
   bool contains(Tile* tile);
   Tile* getBack();
   Tile* getFront();
   void deleteFront();
   void deleteBack();
   int getSize();
   std::string toString();

   //Kristen - S3586968
   std::string colourToString();

   //Tristan - S3784828
   Tile* get(int i);
   void addWhenEmpty(Tile* tile);

private:
   Node* head;
   Node* tail;
   int size;
};

#endif // ASSIGN2_LINKEDLIST_H
