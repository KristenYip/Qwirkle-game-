
#ifndef ASSIGN2_TILE_H
#define ASSIGN2_TILE_H

#include <string>

// Define a Colour type
typedef char Colour;

// Define a Shape type
typedef int Shape;

class Colourizer;

class Tile {
public:
  //Tristan - S3784828
  Tile(Colour colour, Shape shape);
  ~Tile();
  std::string toString();
  bool equals(Tile* tile);
  Colour getColour();
  Shape getShape();

  //Kristen - S3586968
  std::string colourToString();

   Colour colour;
   Shape  shape;
};

#endif // ASSIGN2_TILE_H
