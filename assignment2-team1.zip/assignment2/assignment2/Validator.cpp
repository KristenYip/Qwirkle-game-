#include "Validator.h"
#include "Player.h"
#include "Tile.h"
#include "LinkedList.h"

Validator::Validator() {}

bool Validator::isUpper(std::string string) {
  bool isUpper = false;
  int count = 0;
  int length = string.length() + 1;
  char* s = new char [length];
  std::strcpy(s, string.c_str());
  for (int i = 0; i < length; ++i) {
    if (isupper((int) s[i])) {
      count++;
    }
  }
  if (count == length - 1) {
    isUpper = true;
  }
  return isUpper;
}

bool Validator::charMatches(char character, std::string string) {
  bool matches = false;
  char compareTo[string.size()];
  string.copy(compareTo, string.size());
  if (character == compareTo[0]) {
    matches = true;
  }
  return matches;
}

int Validator::convertCharToInt(char letter, bool useLetter) {
  int number = -1;
  int asciiVal = 0;
  bool foundNumber = false;
  if (useLetter) {
    asciiVal = ASCII_LETTER - 1;
  }
  else {
    asciiVal = ASCII_NUM - 1;
  }
  while (!foundNumber) {
    asciiVal += 1;
    number += 1;
    if ((char) asciiVal == letter) {
      foundNumber = true;
    }
  }
  return number;
}

char Validator::convertToChar(std::string convertFrom, bool useLetter) {
  char character;
  bool foundChar = false;
  int asciiVal = 0;
  if (useLetter) {
    asciiVal = ASCII_LETTER - 1;
  }
  else {
    asciiVal = ASCII_NUM - 1;
  }
  while (!foundChar) {
    asciiVal += 1;
    if (Validator::charMatches((char) asciiVal, convertFrom)) {
      character = (char) asciiVal;
      foundChar = true;
    }
  }
  return character;
}

bool Validator::validInput(std::string input, Player* player, bool place) {
  bool valid = false;
  if (place) {
    if (input.length() == 15) {
      if (input.substr(0,6).compare("place ") == 0) {
        if (input.substr(8,4).compare(" at ") == 0) {
          valid = true;
        }
      }
    }
  }
  else {
    if (input.length() == 10) {
      if (input.substr(0, 8).compare("replace ") == 0) {
        valid = true;
      }
    }
  }
  if (valid && player->getHand()->contains(Validator::getTileFromInput(input, place))) {
    valid = true;
  }
  else {
    valid = false;
  }
  return valid;
}

Tile* Validator::getTileFromInput(std::string input, bool place) {
  Tile* tile;
  if (place) {
    tile = new Tile(Validator::convertToChar(input.substr(6,1), true), Validator::convertCharToInt(Validator::convertToChar(input.substr(7,1), false), false));
  }
  else {
    tile = new Tile(Validator::convertToChar(input.substr(8,1), true), Validator::convertCharToInt(Validator::convertToChar(input.substr(9,1), false), false));
  }
  return tile;
}
