#ifndef ASSIGN2_MENU_H
#define ASSIGN2_MENU_H

#include <iostream>
#include <string>

class Menu {
public:
  //Tristan - S3784828
  Menu();
  std::string displayMainMenu();
  std::string displayStudentInformation();
  std::string displayHelp();
  std::string displayWelcomeMessage();
};

#endif // ASSIGN2_MENU_H
