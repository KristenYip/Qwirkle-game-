#ifndef COLOUR
#define COLOUR

#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <math.h>
#include "Tile.h"
#include "TileCodes.h"
#include "GameBoard.h"

class Colourizer {
public:
    //Kristen - S3586968
    Colourizer();
    std::string colourize(Colour colour, Shape shape);
};
#endif // COLOUR
