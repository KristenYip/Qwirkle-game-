#ifndef ASSIGN2_TILEBAG_H
#define ASSIGN2_TILEBAG_H

#define NUM_TILES 72
#define NUM_TYPES 2
#define ARRAY_SIZE 6

#include "Tile.h"
#include <iostream>
#include <random>
#include <ctime>

class TileCodes;
class LinkedList;

class TileBag {
public:
  //Tristan - S3784828
  TileBag();
  void generateTiles();
  void createRandomList();
  LinkedList* getList();

  Tile* tiles[NUM_TILES];
  int tileCount;
  LinkedList* list;
};

#endif // ASSIGN2_TILEBAG_H
