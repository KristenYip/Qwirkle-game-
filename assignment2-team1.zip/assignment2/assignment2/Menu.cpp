#include "Menu.h"

Menu::Menu() {

}

std::string Menu::displayMainMenu()
{
  std::string mainMenu = "";
  mainMenu += "Menu\n";
  mainMenu += "----\n";
  mainMenu += "1. New Game\n";
  mainMenu += "2. Load Game\n";
  mainMenu += "3. Show Student Information\n";
  mainMenu += "4. Quit\n";
  return mainMenu;
}

std::string Menu::displayStudentInformation()
{
  std::string studentInfo = "";
  studentInfo += "\n-------------------------------------\n";
  studentInfo += "Name: Tristan Macaulay\n";
  studentInfo += "ID: s3784828\n";
  studentInfo += "Email: s3784828@student.rmit.edu.au\n\n";
  studentInfo += "Name: Xuan Ye\n";
  studentInfo += "ID: s3586968\n";
  studentInfo += "Email: s3586968@student.rmit.edu.au\n\n";
  studentInfo += "Name: Johnson Nguyen\n";
  studentInfo += "ID: s3722955\n";
  studentInfo += "Email: s3722955@student.rmit.edu.au\n\n";
  studentInfo += "Name: Evan Mason\n";
  studentInfo += "ID: s3688949\n";
  studentInfo += "Email: s3688949@student.rmit.edu.au\n";
  studentInfo += "-------------------------------------\n";

  return studentInfo;
}

std::string Menu::displayHelp() {
  std::string help = "";
  help += "----------HELP----------\n";
  help += "1. place 'X' at 'Y'  \n";
  help += "2. replace 'X'\n";
  help += "3. forfeit\n";
  help += "X = a tile in your hand\n";
  help += "Y = a position \n";
  help += "------------------------\n";
  return help;
}

std::string Menu::displayWelcomeMessage() {
  std::string message = "";
  message += "\n----------------------\n";
  message += "\n  WELCOME TO QWIRKLE  \n";
  message += "\n----------------------\n";
  return message;
}
