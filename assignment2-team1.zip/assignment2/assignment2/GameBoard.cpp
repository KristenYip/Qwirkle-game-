#include "GameBoard.h"
#include "Player.h"
#include "Tile.h"
#include "TileBag.h"
#include "LinkedList.h"
#include "Validator.h"

GameBoard::GameBoard(int rows, int cols, TileBag* tileBag) :
  rows(rows),
  cols(cols),
  tileBag(tileBag)
{
  playerCount = 0;
  emptyBoard = true;

  for (int row = 0; row < rows; ++row) {
    std::vector<Tile> tile;
    for (int col = 0; col < cols; ++col) {
      tile.push_back(Tile('0', 0));
    }
    tileBoard.push_back(tile);
  }
  int startingVal = 0;
  int iterator = 2;
  for (int row = 0; row < rows; ++row) {
    if (remainder(row, 2) == 0) {
      startingVal = 1;
    }
    else {
      startingVal = 0;
    }
    for (int col = startingVal; col < cols; col += iterator) {
      tileBoard[row][col] = Tile('1', 1);
    }
  }
}

GameBoard::~GameBoard() {
  tileBag->getList()->clear();
  for (int i = 0; i < NUM_PLAYERS; ++i) {
    delete players[i];
  }
}

std::string GameBoard::displayGameBoard(bool save) {
  std::string gameBoard = "";
  int asciiVal = ASCII_LETTER - 1;
  int iterator = 2;
  int numPossibleChars = 5;
  Tile* invalidTile = new Tile('1', 1);
  int col = GameBoard::divideCol(cols);
  int finalCol = GameBoard::numPossibleChars(cols);

  int asciiNum = ASCII_NUM - 1;
  int asciiNum2 = ASCII_NUM;

  gameBoard += "     ";
  for (int i = 0; i < col; ++i) {
    asciiNum++;
    if (i != col - 1) {
      for (int j = 0; j < numPossibleChars; ++j) {
        gameBoard += (char) asciiNum;
        gameBoard += (char) asciiNum2;
        gameBoard += "   ";
        asciiNum2 += iterator;
      }
    }
    else {
      for (int j = 0; j < finalCol; ++j) {
        gameBoard += (char) asciiNum;
        gameBoard += (char) asciiNum2;
        gameBoard += "   ";
        asciiNum2 += iterator;
      }
    }
    asciiNum2 = ASCII_NUM;
  }

  gameBoard += "\n";
  gameBoard += "   ";
  for (int i = 0; i <= (int) cols / iterator; ++i) {
    gameBoard += "-----";
  }

  gameBoard += "\n";
  for (int row = 0; row < rows; ++row) {
    asciiVal += 1;
    gameBoard += (char) asciiVal;
    if (remainder(row, 2) == 0) {
      gameBoard += "  | ";
    }
    else {
      gameBoard += "    | ";
    }
    for (int col = 0; col < cols; ++col) {
      if (!tileBoard[row][col].equals(invalidTile)) {
        if (save) {
          gameBoard += tileBoard[row][col].toString();
        }
        else {
          gameBoard += tileBoard[row][col].colourToString();
        }
        gameBoard += " | ";
      }
    }
    gameBoard += "\n";
  }

  gameBoard += "   ";
  for (int i = 0; i <= (int) cols / iterator; ++i) {
    gameBoard += "-----";
  }
  gameBoard += "\n";
  gameBoard += "       ";
  asciiNum = ASCII_NUM - 1;
  asciiNum2 = ASCII_NUM + 1;
for (int i = 0; i < col; ++i) {
  asciiNum++;
  if ( i != col - 1) {
    for (int j = 0; j < numPossibleChars; ++j) {
      gameBoard += (char) asciiNum;
      gameBoard += (char) asciiNum2;
      gameBoard += "   ";
      asciiNum2 += iterator;
    }
  }
  else {
    for (int j = 0; j < finalCol; ++j) {
      gameBoard += (char) asciiNum;
      gameBoard += (char) asciiNum2;
      gameBoard += "   ";
      asciiNum2 += iterator;
    }
  }
  asciiNum2 = ASCII_NUM + 1;
}
return gameBoard;
}

bool GameBoard::inBounds(int row, int col) {
  bool inBounds = true;
  if ((col > cols || row > rows) || (col < 0 || row < 0)) {
    inBounds = false;
  }
  Tile* validTile = new Tile('0', 0);
  if (inBounds == true) {
    if (!tileBoard[row][col].equals(validTile)) {
      inBounds = false;
    }
  }
  return inBounds;
}

bool GameBoard::addPosition(std::string input, Player* player, Replay* r) {
  Validator* v = new Validator();
  bool posAdded = false;
  int countRow = -1;
  int countCol = -1;
  std::string position = input.substr(12,3);
  countRow = convertRow(position.substr(0,1));
  countCol = convertCol(position.substr(1,2));
  Tile proposedTile = Tile(v->convertToChar(input.substr(6,1), true),
  v->convertCharToInt(v->convertToChar(input.substr(7,1), false), false));
  Tile* replayTile = new Tile(v->convertToChar(input.substr(6,1), true),
  v->convertCharToInt(v->convertToChar(input.substr(7,1), false), false));
  if (inBounds(countRow, countCol) && proposeTile(&proposedTile, countCol, countRow, player)) {
    tileBoard[countRow][countCol] = proposedTile;
    r->addToReplay(new Tile(v->convertToChar(position.substr(0,1), true), countCol),replayTile);
    posAdded = true;
  }
  return posAdded;
}

bool GameBoard::directionCheckandScoreColour(Tile* proposedTile, int locRow, int locCol, int dirRow, int dirCol, int* tileScorePtr){

  bool checkPass = true;

  if ((locCol+dirCol >= 0 && locCol+dirCol<cols) && (locRow+dirRow >= 0 && locRow+dirRow<rows)){

    if (proposedTile->equals(&tileBoard[locRow][locCol])){

      checkPass = false;

    }

    else if (tileBoard[locRow+dirRow][locCol+dirCol].getColour()!=proposedTile->getColour() && tileBoard[locRow+dirRow][locCol+dirCol].getColour()!='0'){

      checkPass = false;

    }

    else if (tileBoard[locRow+dirRow][locCol+dirCol].getColour()==proposedTile->getColour()){

      (*tileScorePtr)++;
      if ((*tileScorePtr)==6){

        (*tileScorePtr)+=6;
        std::cout << "QWIRKLE!!!";

      }
    }

      if (checkPass == true){

      checkPass = directionCheckandScoreColour(proposedTile, locRow+dirRow, locCol+dirCol, dirRow, dirCol, tileScorePtr);
      }

  }

  return checkPass;

}

bool GameBoard::directionCheckandScoreShape(Tile* proposedTile, int locRow, int locCol, int dirRow, int dirCol, int* tileScorePtr){

  bool checkPass = true;

  if ((locCol+dirCol >= 0 && locCol+dirCol<cols) && (locRow+dirRow >= 0 && locRow+dirRow<rows)){

    if(proposedTile->equals(&tileBoard[locRow][locCol])){

      checkPass = false;

    }

    else if (tileBoard[locRow+dirRow][locCol+dirCol].getShape()!=proposedTile->getShape() && tileBoard[locRow+dirRow][locCol+dirCol].getColour()!='0'){

      checkPass = false;

    }

    else if (tileBoard[locRow+dirRow][locCol+dirCol].getShape()==proposedTile->getShape()){

      (*tileScorePtr)++;
      if ((*tileScorePtr)==6){

        (*tileScorePtr)+=6;
        std::cout << "QWIRKLE!!!";

      }
    }

      if (checkPass == true){

      checkPass = directionCheckandScoreShape(proposedTile, locRow+dirRow, locCol+dirCol, dirRow, dirCol, tileScorePtr);
    }

  }

  return checkPass;

}


bool GameBoard::proposeTile(Tile* proposedTile, int propCol, int propRow, Player* player){

  bool validPosition = true;
  bool hasNeighbor = false;
  int tileScore = 1;
  int* tileScorePtr = &tileScore;

  if (!emptyBoard){

    if (propRow!=0 && propCol!=0){

      if (tileBoard[propRow-1][propCol-1].getColour()!='0'){
        hasNeighbor = true;

        if (tileBoard[propRow-1][propCol-1].getColour()!=proposedTile->getColour() &&
        tileBoard[propRow-1][propCol-1].getShape()!=proposedTile->getShape()){

        validPosition = false;

        }

        else if (tileBoard[propRow-1][propCol-1].getColour()==proposedTile->getColour() && tileBoard[propRow][propCol].getColour()=='0'){

        validPosition = directionCheckandScoreColour(proposedTile,propRow,propCol,-1,-1,tileScorePtr);

        }

        else if (tileBoard[propRow-1][propCol-1].getShape()==proposedTile->getShape() && tileBoard[propRow][propCol].getColour()=='0'){

        validPosition = directionCheckandScoreShape(proposedTile,propRow,propCol,-1,-1,tileScorePtr);

      }

    }
  }

  if (propRow<rows-1 && propCol!=0){

    if (tileBoard[propRow+1][propCol-1].getColour()!='0' && (propRow<rows && propCol!=0)){

      hasNeighbor = true;

      if (tileBoard[propRow+1][propCol-1].getColour()!=proposedTile->getColour() &&
      tileBoard[propRow+1][propCol-1].getShape()!=proposedTile->getShape()){

      validPosition = false;

      }

      else if (tileBoard[propRow+1][propCol-1].getColour()==proposedTile->getColour() && tileBoard[propRow][propCol].getColour()=='0'){

      validPosition = directionCheckandScoreColour(proposedTile,propRow,propCol,1,-1,tileScorePtr);

      }

      else if (tileBoard[propRow+1][propCol-1].getShape()==proposedTile->getShape() && tileBoard[propRow][propCol].getColour()=='0'){

      validPosition = directionCheckandScoreShape(proposedTile,propRow,propCol,1,-1,tileScorePtr);

      }

    }
  }

  if (propRow!=0 && propCol<cols-1){

    if (tileBoard[propRow-1][propCol+1].getColour()!='0'){

      hasNeighbor = true;

      if (tileBoard[propRow-1][propCol+1].getColour()!=proposedTile->getColour() &&
      tileBoard[propRow-1][propCol+1].getShape()!=proposedTile->getShape()){

      validPosition = false;

      }

      else if (tileBoard[propRow-1][propCol+1].getColour()==proposedTile->getColour() && tileBoard[propRow][propCol].getColour()=='0'){

      validPosition = directionCheckandScoreColour(proposedTile,propRow,propCol,-1,1,tileScorePtr);

      }

      else if (tileBoard[propRow-1][propCol+1].getShape()==proposedTile->getShape() && tileBoard[propRow][propCol].getColour()=='0'){

      validPosition = directionCheckandScoreShape(proposedTile,propRow,propCol,-1,1,tileScorePtr);

      }

    }
  }

  if (propRow<rows-1 && propCol<cols-1){

    if (tileBoard[propRow+1][propCol+1].getColour()!='0'){
      hasNeighbor = true;

      if (tileBoard[propRow+1][propCol+1].getColour()!=proposedTile->getColour() &&
      tileBoard[propRow+1][propCol+1].getShape()!=proposedTile->getShape()){

      validPosition = false;

      }

      else if (tileBoard[propRow+1][propCol+1].getColour()==proposedTile->getColour() && tileBoard[propRow][propCol].getColour()=='0'){

      validPosition = directionCheckandScoreColour(proposedTile,propRow,propCol,1,1,tileScorePtr);

      }

      else if (tileBoard[propRow+1][propCol+1].getShape()==proposedTile->getShape() && tileBoard[propRow][propCol].getColour()=='0'){

      validPosition = directionCheckandScoreShape(proposedTile,propRow,propCol,1,1,tileScorePtr);

      }
    }
  }

    if (!hasNeighbor){

      validPosition = false;

    }
  }

  else{

    emptyBoard = false;
    tileScore = 1;

  }

  if (validPosition ==true){

    player->addScore(tileScore);
    std::cout << player->getName();

  }

  return validPosition;

}

void GameBoard::addPlayer(std::string name, int score) {
  players[playerCount] = new Player(name, score, tileBag);
  playerCount++;
}

Player* GameBoard::getPlayer(int i) {
  return players[i];
}


std::string GameBoard::displayInfo(int playersTurn) {
  std::string playerInfo = "";
  playerInfo += players[playersTurn]->getName();
  playerInfo += ", its your turn\n";
  for (int i = 0; i < NUM_PLAYERS; ++i) {
    playerInfo += "Score for ";
    playerInfo += players[i]->getName();
    playerInfo += ": ";
    playerInfo += std::to_string(players[i]->getScore());
    playerInfo += "\n";
  }
  return playerInfo;
}

bool GameBoard::checkPlayerHands() {
  bool gameEnded = false;
  for (int i = 0; i < NUM_PLAYERS; ++i) {
    if (players[i]->getHand()->getSize() == 0) {
      gameEnded = true;
    }
  }
  return gameEnded;
}

std::string GameBoard::getFinalResults() {
  std::string finalResults = "";
  int bestScore = 0;
  std::string winner = "";
  for (int i = 0; i < NUM_PLAYERS; ++i) {
    if (players[i]->getScore() >= bestScore) {
      winner = "";
      winner += players[i]->getName();
      bestScore = players[i]->getScore();
    }
  }
  winner += " won the match with a score of ";
  winner += std::to_string(bestScore);
  int loserScore = 0;
  std::string loser = "";
  for (int i = 0; i < NUM_PLAYERS; ++i) {
    if (players[i]->getScore() < bestScore) {
      loser = "";
      loser += players[i]->getName();
      loserScore = players[i]->getScore();
    }
  }
  loser += " lost the match with a score of ";
  loser += std::to_string(loserScore);
  finalResults += "GAME OVER\n";
  finalResults += winner;
  finalResults += "\n";
  finalResults += loser;
  finalResults += "\n";

  return finalResults;
}

int GameBoard::convertRow(std::string row) {
  Validator* v = new Validator();
  return v->convertCharToInt(v->convertToChar(row.substr(0, 1), true), true);
}

int GameBoard::convertCol(std::string col) {
  Validator* v = new Validator();
  return v->convertCharToInt(v->convertToChar(col.substr(0, 1), false), false) * 10
  + v->convertCharToInt(v->convertToChar(col.substr(1, 1), false), false);
}

int GameBoard::divideCol(int col) {
  int count = 0;
  for (int i = 1; i < col; i = count * 10) {
    count++;
  }
  return count;
}

int GameBoard::numPossibleChars(int cols) {
  int numPossibleChars = 0;
  int increase = 10;
  int multiplier = GameBoard::divideCol(cols);
  numPossibleChars = ((cols + increase) - (multiplier * increase)) / 2;
  return numPossibleChars;
}
