#include "Player.h"
#include "LinkedList.h"
#include "TileBag.h"

Player::Player(std::string name, int score, TileBag* tileBag) :
  name(name),
  score(score),
  tileBag(tileBag)
{
  hand = new LinkedList();
  Player::generateHand(hand);
}

Player::~Player() {
  hand->clear();
  tileBag->getList()->clear();
  score = 0;
  name = nullptr;
}

void Player::generateHand(LinkedList* list) {
  while (list->getSize() <= HAND_SIZE) {
    list->addFront(tileBag->getList()->getFront());
    tileBag->getList()->deleteFront();
  }
}

LinkedList* Player::getHand() {
  return hand;
}

std::string Player::getHandInfo() {
  std::string handString = "";
  handString += "Your hand is: \n";
  handString += hand->colourToString();
  return handString;
}

std::string Player::getName() {
  return name;
}

int Player::getScore() {
  return score;
}

void Player::addScore(int scored){

  score += scored;

}

std::string Player::toString() {
  std::string player = "";
  player += "Name: ";
  player += name;
  player += "\nScore: ";
  player += std::to_string(score);
  player += "\nHand: ";
  player += hand->toString();
  return player;
}
